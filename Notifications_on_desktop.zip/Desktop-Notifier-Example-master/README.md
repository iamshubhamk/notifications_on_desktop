# Desktop-Notifier-Example
An exemplar desktop notifier application using notify2

![](https://github.com/nikhilkumarsingh/Desktop-Notifier-Example/blob/master/screenshot1.png)
